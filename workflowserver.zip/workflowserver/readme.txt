/*
 * Workflow Server
 * https://workflowengine.io/server/
 */
 
Workfow Server is a ready-to-use Workflow Engine-based application that you can deploy into your infrastructure. It can be integrated with NodeJS, PHP, Ruby, .NET, or Java applications via an HTTP API. Workflow Server is a key component for managing the lifecycle of business objects within your enterprise.

How to configure and run:
1. Extract the 'workflowserver.zip' archive
2. Run the folowing SQL-scripts on a Database (for MS SQL Server from SQL\MSSQL folder, for PostgreSQL from SQL\PostgreSQL, for Oracle from SQL\Oracle folder,for MySql from SQL\MySql folder):
	2.1. CreatePersistenceObjects.sql
	2.2. WorkflowServerScripts.sql
3. Make the following changes to the bin\config.json file:
	3.1. Change the URL parameter to the IP and the port of the HTTP listener. Most likely you'll need to leave it as it is.
	3.2. Specify "mssql" or "postgresql" in the "provider" parameter depending on what database provider you are using
	3.3. Change the ConnectionString parameter to match your database provider connection settings. For more information, have a look at these instructions for MS SQL and PostgreSQL.
	
4.1. Workflow Server supports console and service modes on Windows:
	4.1.1. Run the 'runserver.bat' file to run it in the Console mode
	4.1.2. Run the 'installservice.bat' as administrator to run it in the Service mode
4.2. For Linux/MacOS: 
	4.2.1. Install .NET Core 2
	4.2.2. Open the terminal in a folder where you extracted the 'workflowserver.zip' archive to
	4.2.3. Run the following command: './runserver.sh'
5. Open http://localhost:8077 in a browser.
6. Upload your license key via the Dashboard or save the licence key as 'license.key' into the folder.
7. Fill in Callback API urls at http://localhost:8077/?apanel=callbackapi to perform integration.

If you need any assistance, please email us at sales@optimajet.com.

Official web site: https://workflowengine.io/server/
Documentation: https://dwkit.com/documentation/
Demo: http://server.workflowengine.io/
Email: sales@optimajet.com