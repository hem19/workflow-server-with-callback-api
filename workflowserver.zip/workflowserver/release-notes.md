﻿<!--Stay on the edge of our innovations and learn about the changes made to Workflow Server with each of our releases.-->
# Release Notes

## 2.4

- Updated to Workflow Engine .NET 4.0

**The following additional actions must be taken to upgrade to Workflow Server 2.4:**

- Run the SQL  script `update_WFE_4_0.sql` for all relative databases.

## 2.3

- Added localization for German, French, Spanish, Italian, Portuguese, Turkish, and Russian languages.
- `SchemaName` setting has been added to specify the database schema to which the server is connected. 
- The `GetSchemeList` method has been added to the server API, this method returns a list of schemes that exist on the server.
- The logging system has been added. Errors, debug information and informational messages are logged. Logging targets can be console, debug output or files. For windows service, logging can also be done in the Windows Event Log.
-  The `LogInfo`,` LogError`, `LogMessage` methods have been added to the server API - methods for writing to the log from outside the server.
- The following new features are available in the `WorkflowRuntime` object, which is always available in standard WFE actions. `runtime.Logger` - returns logger, for recording messages to the log. `runtime.LogError ()`, `runtime.LogDebug ()`, `runtime.LogInfo ()` are methods for writing messages to the log.
- The docker container was published , containing the Workflow Server with the ability to transfer all the configuration settings to it.

## 2.2

- The MongoDB support has been added, this type of connection also works with the Cosmos DB.

---

## 2.1

- Added Oracle and MySQL support
- The `ExecuteCommand` method from WorkflowAPI returns information on whether the command was executed and process state after execution (including all process parameters)
- The source code of a console application which you can connect your `IWorkflowActionProvider` and `IWorkflowRuleProvider` to and perform fine-tuning of Workflow Engine was uploaded to (GitHub)[https://github.com/optimajet/workflowserver]

---

## 2.0

- First release of Workflow Server 2.0